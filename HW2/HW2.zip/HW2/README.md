# This file include part1 (index.html and fiststyle.css) and part2 (hw2_part2) of HW2

# Author : Jinglin Li (jxl163530)

# You can go to http://www.utdallas.edu/~jxl163530/ to see the output of part1. 

# For the part1 and part2, you can use chrome or firefox to check. 

