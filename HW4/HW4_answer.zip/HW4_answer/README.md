HW4_WPL author: Jinglin Li (jxl163530)

1. XML Schema
Open "bookinformation.xsd" with notepad.

2. XML Document Creation and Display
Creation: open "BookInformation.xml" with notepad.
Display: 1. open "displaybook.html" with Firefox. By clicking botton "get book information", books can be displayed. 
         2. double click "BookInformation.xml". It can be opened with IE. Xpath queries could display. (src file is "xpath.xsl").


3. XML to JSON
I have put the whole program into a jar file, "XML_to_Json-0.01-SNAPSHOT.jar" under "XML_to_Json\target" . I also copy this jar file into the root file. 
You can either go to "XML_to_Json\target" or this root file and run on the command:

java -jar XML_to_Json-0.0.1-SNAPSHOT.jar XMLToJsonTest.xml

If you want to change the "XMLToJsonTest.xml" file, you need to run as Maven in the src file and refresh and get the updated jar file and run. 

