This file include Carousel Template for Bootstrap, and jQuery and CSS library for that (Carousel Template for Bootstrap_files), and ContactMe.html.

Author: Jinglin Li(jxl163530)

Please use Chrome to run and test.

Note: For the individual cell color change (last question), I only change the font and background color of the orginal cells but not the newly added cells because it is not required. (To make life easier :))



