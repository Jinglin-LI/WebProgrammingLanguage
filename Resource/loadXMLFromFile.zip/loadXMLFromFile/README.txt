loadAndParseXMLFile.html

	1. Host the loadAndParseXMLFile.html and sampleBook.xml on the same web server



loadAndParseLocalXMLFile.html

	On Firefox: should work by default.

	On Chrome: 
	  1. navigate to the path of your Chrome installation via a command prompt and run the following:
	     a. Windows: Chrome.exe --disable-web-security --user-data-dir
	     b. Linux: Chrome --disable-web-security --user-data-dir


