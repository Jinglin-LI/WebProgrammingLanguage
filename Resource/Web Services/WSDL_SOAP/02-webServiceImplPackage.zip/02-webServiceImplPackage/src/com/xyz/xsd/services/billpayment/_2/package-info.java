@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.xyz.com/xsd/services/BillPayment/2.2", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.xyz.xsd.services.billpayment._2;
