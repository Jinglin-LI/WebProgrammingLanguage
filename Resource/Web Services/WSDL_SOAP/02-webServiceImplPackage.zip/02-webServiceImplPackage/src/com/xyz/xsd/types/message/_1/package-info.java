@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.xyz.com/xsd/types/message/1.2")
package com.xyz.xsd.types.message._1;
