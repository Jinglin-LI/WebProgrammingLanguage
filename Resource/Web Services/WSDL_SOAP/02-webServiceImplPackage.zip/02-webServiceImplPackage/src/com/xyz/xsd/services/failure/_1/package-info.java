@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.xyz.com/xsd/services/Failure/1.0", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.xyz.xsd.services.failure._1;
